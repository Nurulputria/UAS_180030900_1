package com.bh183.azizah;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class DatabaseHandler extends SQLiteOpenHelper {

    private final static int DATABASE_VERSION = 2;
    private final static String DATABASE_NAME = "db_filmku";
    private final static String TABLE_FILM = "t_film";
    private final static String KEY_ID_FILM = "ID_Film";
    private final static String KEY_JUDUL = "Judul";
    private final static String KEY_GAMBAR = "Gambar";
    private final static String KEY_TGL = "Tanggal";
    private final static String KEY_SUTRADARA = "Sutradara";
    private final static String KEY_SINOPSIS_FILM = "Sinopsis_Film";
    private final static String KEY_GENRE= "Genre";
    private SimpleDateFormat sdFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm", Locale.getDefault());
    private Context context;

    public DatabaseHandler(Context ctx) {
        super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = ctx;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_FILM= "CREATE TABLE " + TABLE_FILM
                + "(" + KEY_ID_FILM + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_JUDUL + " TEXT, " + KEY_GAMBAR + " TEXT, "
                + KEY_TGL + " DATE, " + KEY_SUTRADARA + " TEXT, "
                + KEY_SINOPSIS_FILM + " TEXT, " + KEY_GENRE + " TEXT);";

        db.execSQL(CREATE_TABLE_FILM);
        inisialisasiFilmAwal(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_FILM;
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }

    public void tambahFilm(Film dataFilm) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataFilm.getJudul());
        cv.put(KEY_GAMBAR, dataFilm.getGambar());
        cv.put(KEY_TGL, sdFormat.format(dataFilm.getTanggal()));
        cv.put(KEY_SUTRADARA, dataFilm.getSutradara());
        cv.put(KEY_SINOPSIS_FILM, dataFilm.getSinopsisFilm());
        cv.put(KEY_GENRE, dataFilm.getGenre());
        db.insert(TABLE_FILM, null, cv);
        db.close();
    }

    public void tambahFilm(Film dataFilm, SQLiteDatabase db) {
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataFilm.getJudul());
        cv.put(KEY_GAMBAR, dataFilm.getGambar());
        cv.put(KEY_TGL, sdFormat.format(dataFilm.getTanggal()));
        cv.put(KEY_SUTRADARA, dataFilm.getSutradara());
        cv.put(KEY_SINOPSIS_FILM, dataFilm.getSinopsisFilm());
        cv.put(KEY_GENRE, dataFilm.getGenre());
        db.insert(TABLE_FILM, null, cv);
    }

    public void editFilm(Film dataFilm) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataFilm.getJudul());
        cv.put(KEY_GAMBAR, dataFilm.getGambar());
        cv.put(KEY_TGL, sdFormat.format(dataFilm.getTanggal()));
        cv.put(KEY_SUTRADARA, dataFilm.getSutradara());
        cv.put(KEY_SINOPSIS_FILM, dataFilm.getSinopsisFilm());
        cv.put(KEY_GENRE, dataFilm.getGenre());

        db.update(TABLE_FILM, cv, KEY_ID_FILM + "=?", new String[]{String.valueOf(dataFilm.getIdFilm())});
        db.close();
    }

    public void hapusFilm(int idFilm) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_FILM, KEY_ID_FILM + "=?", new String[]{String.valueOf(idFilm)});
        db.close();
    }

    public ArrayList<Film> getAllFilm() {
        ArrayList<Film> dataFilm = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_FILM;
        SQLiteDatabase db = getReadableDatabase();
        Cursor csr = db.rawQuery(query, null);
        if(csr.moveToFirst()){
            do {
                Date tempDate = new Date();
                try {
                    tempDate = sdFormat.parse(csr.getString(3));
                } catch (ParseException er) {
                    er.printStackTrace();
                }
                Film tempFilm = new Film(
                        csr.getInt(0),
                        csr.getString(1),
                        csr.getString(2),
                        tempDate,
                        csr.getString(4),
                        csr.getString(5),
                        csr.getString(6)
                );

                dataFilm.add(tempFilm);
            } while (csr.moveToNext());
        }

        return dataFilm;
    }

    private String storeImageFile(int id) {
        String location;
        Bitmap image = BitmapFactory.decodeResource(context.getResources(), id);
        location = InputActivity.saveImageToInternalStorage(image, context);
        return location;
    }

    private void inisialisasiFilmAwal(SQLiteDatabase db){
        int idFilm = 0;
        Date tempDate = new Date();

        // Menambah data film ke-1
        try{
            tempDate = sdFormat.parse("06/03/2020 14:00");
        } catch (ParseException er) {
            er.printStackTrace();
        }


        Film film1 = new Film(
                idFilm,
                "Mahasiswi Baru ",
                storeImageFile(R.drawable.film1),
                tempDate,
                "Monty Tiwa",
                "Di usianya yang sudah lanjut, Lastri (Widyawati) ingin sekali kuliah di perguruan tinggi. Saat menjadi mahasiswi baru, Lastri bersahabat dengan Danny (Morgan Oey), Sarah (Mikha Tambayong), Erfan (Umay Shahab) dan Reva (Sonia Alyssa).\n" +
                        "\n" +
                        "Awalnya mereka semua memanggilnya Oma, tetapi Lastri ingin dipanggil dengan namanya saja Lastri seperti teman-teman lainnya. Akhirnya Ia mulai dipanggil dengan namanya.\n" +
                        "Bahkan saat putrinya tahu terkejut karena seumur-umur Ia tak pernah panggil ibunya dengan nama sebutan lastri saja.\n" +
                        "\n" +
                        "Mereka membentuk sebuah geng. Geng Lastri sering membuat kehebohan di kampus dan menimbulkan kericuhan hingga anak Lastri, Anna (Karina Suwandi), pusing menghadapi ibunya yang ikut-ikutan bandel seperti pulang larut malam dan sering keluyuran.\n" +
                        "\n" +
                        "Kuliah Lastri mulai dipertaruhkan saat Chaerul (Slamet Rahardjo), dekan fakultas, merasa Lastri tak pantas melanjutkan kuliah karena keonarannya di kampus.\n" +
                        "\n" +
                        "Lastri juga sering mendapat masalah hingga luka pada dirinya. Namun Ia tetap tak menyerah. Bahkan dekan mengancam akan mengeluarkannya setelah melihat nilai akhir semester nanti.\n",
                "Comedy, School"
        );

        tambahFilm(film1, db);
        idFilm++;

        // Data Film ke-2
        try{
            tempDate = sdFormat.parse("24/12/2018 22:00");
        } catch (ParseException er) {
            er.printStackTrace();
        }

        Film film2 = new Film(
                idFilm,
                "The Raid ",
                storeImageFile(R.drawable.film2),
                tempDate,
                "Gareth Evans",
                "Ada sebuah daerah kumuh di Jakarta yang berdiri apartemen telantar yang tak tertembus dan menjadi rumah aman bagi gangster, penjahat dan pembunuh yang paling berbahaya.\n" +
                        "\n" +
                        "Apartemen kumuh tersebut tak tersentuh oleh para rival gembong narkoba terkenal Tama Riyadi yang diperankan oleh Ray Sahetapy, bahkan untuk perwira polisi paling berani sekalipun.\n" +
                        "\n" +
                        "Semuanya berubah ketika sebuah tim polisi senjata dan taktik khusus berjumlah 20 orang ditugaskan untuk menyerbu bangunan tersebut dan mengakhiri teror Tama untuk selamanya.\n" +
                        "\n" +
                        "Di bawah kegelapan dan keheningan fajar, Rama diperankan oleh Iko Uwais, seorang calon ayah dan perwira polisi elit baru, dalam regu yang dipimpin oleh Sersan Jaka (Joe Taslim), tiba di blok apartemen Tama dengan petunjuk Letnan Wahyu (Pierre Gruno).\n" +
                        "\n" +
                        "Setelah berpapasan dengan Gofar (Iang Darmawan) salah seorang penghuni apartemen tersebut, mereka menerobos masuk dan dengan hati-hati mengamankan para penjahat penghuninya. Tak semudah yang diharapkan disana terdapat juga musuh profesional Mad Dog (Yayan Ruhian).\n",
                "Action"
        );

        tambahFilm(film2, db);
        idFilm++;

        // Data Film ke-3
        try{
            tempDate = sdFormat.parse("29/12/2018 20:00");
        } catch (ParseException er) {
            er.printStackTrace();
        }

        Film film3 = new Film(
                idFilm,
                "Negeri Van Oranje",
                storeImageFile(R.drawable.film3),
                tempDate,
                "Endri Pelita",
                "Perjalanan Lintang yang diperankan oleh Tatjana Saphira membawanya sampai ke hari ini, dimana 1 hari sebelum pernikahannya. Dia mengingat kembali tentang sahabat – sahabat baiknya. Dimulai dari Banjar diperankan oleh Arifin Putra, Wicak (Abimana Aryasatya), Daus (Ge Pamungkas) dan Geri (Chicco Jerikho).\n" +
                        "\n" +
                        "Mereka bersama – sama menjalani pendidikan S2 di Belanda, namun kuliah mereka di kota yang berbeda satu sama lain. Persahabatan mereka sangat erat dan menyatukan mereka dan hal tersebut membawa Lintang pada cintanya. Namun masalah besar terjadi diantara mereka dan hal tersebut membuat keputusan yang rumit. Hari ini Lintang menikahi salah satu dari mereka.\n",
                "Drama, Romance, Friendship"
        );

        tambahFilm(film3, db);
        idFilm++;

        // Data Film ke-4
        try{
            tempDate = sdFormat.parse("30/06/2016 19:00");
        } catch (ParseException er) {
            er.printStackTrace();
        }

        Film film4 = new Film(
                idFilm,
                "Rudy Habibie",
                storeImageFile(R.drawable.film4),
                tempDate,
                "Hanung Bramantyo",
                "Ini adalah cerita dari masa muda nya Rudy Habibie yang tak lain sekarang dikenal sebagai BJ Habibie, Presiden Indonesia ke-3 dan dikenal sebagai sosok teknokrat. Pesan terakhir ayahnya yang Rudy ingat adalah tentang menjadi seorang yang berguna bagi banyak orang.\n" +
                        "\n" +
                        "Dia ingin membuat sebuah pesawat dan akhirnya harus kuliah di RWTH AACHEN UNIVERSITY, Jerman. Dalam kondisi yang terbatas dan rindu akan kampung halaman, Dia belajar tentang persahabatan, cinta hingga pengkhianatan bersama para mahasiswa Indonesia yang juga baru dikenalnya di sana.\n" +
                        "\n",
                "Drama, Romance"
        );

        tambahFilm(film4, db);
        idFilm++;

        // Data Film ke-5
        try{
            tempDate = sdFormat.parse("17/02/2012 19:00");
        } catch (ParseException er) {
            er.printStackTrace();
        }

        Film film5 = new Film(
                idFilm,
                "Negeri 5 Menara",
                storeImageFile(R.drawable.film5),
                tempDate,
                "Affandi Abdul Rachman",
                "Alif lahir di sebuah kampung kecil di pinggir Danau Maninjau. Ia tidak pernah menginjakkan kaki di luar tanah kelahirannya. Alif bercita-cita kelak melanjutkan pendidikannya ke Institut Teknologi Bandung (ITB), salah satu kampus terkenal di Pulau Jawa.\n" +
                        "\n" +
                        "\n" +
                        "Namun sang amak (ibu) ingin Alif masuk pesantren agar bisa bermanfaat seperti Bung Hatta dan Buya Hamka. Dengan setengah hati, Alif menjalani keputusan orang tuanya dan bersekolah di Pondok Madani sebuah pesantren di sudut kota Ponorogo, Jawa Timur.\n" +
                        "\n" +
                        "\n" +
                        "Kedatangannya di Pondok Madani yang terkesan kampungan dengan berbagai peraturan yang ketat semakin meremukkan semangat Alif. Namun seiring berjalannya waktu, ia pun mulai bersahabat dengan teman-teman dari berbagai daerah.\n" +
                        "\n" +
                        "\n" +
                        "Semangat anak-anak muda ini untuk belajar dan bersungguh-sungguh, terinspirasi oleh perkataan Ustad Salman, salah seorang guru di pondok pesantren itu.\n" +
                        "\n" +
                        "\n" +
                        "\"Man Jadda Wa Jada..Man Jadda Wa Jada\" (Barang siapa bersungguh-sungguh pasti akan berhasil).\n" +
                        "Mantra inilah yang menambah tekad dan kesungguhan meraih cita-cita dan membuat mereka sukses dalam kehidupannya masing-masing.\n",
                "Frienship"
        );

        tambahFilm(film5, db);
    }
}
